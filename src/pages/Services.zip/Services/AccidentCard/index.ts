export { default } from './AccidentCard';

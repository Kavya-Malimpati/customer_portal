export { default } from './SafetyTipsCard';
